from lexer import Lexer
from my_parser import Parser


while True:
    text_input = input('MyLang -> ')

    lexer = Lexer().get_lexer()
    tokens = lexer.lex(text_input)

    # for token in tokens:
    #     print(token)

    pg = Parser()
    pg.parse()
    parser = pg.get_parser()
    parser.parse(tokens).eval()
