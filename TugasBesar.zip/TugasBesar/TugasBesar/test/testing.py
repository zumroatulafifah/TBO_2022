arr = []

print(arr)
