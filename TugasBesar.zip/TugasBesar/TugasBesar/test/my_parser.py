from rply import ParserGenerator
from my_ast import Number, Sum, Sub, Mul, Div, Print, String, Var_Assign, Get_VarValue, Typecast_str, Typecast_int, Mod, Diskrit, Arr_Declaration, Arr_Add, Access_Arr, Arr_Dec_With_Size, And, Or, Not, Xor, Greater, Less, Equal


class Parser():
    def __init__(self):
        self.pg = ParserGenerator(
            ['NUMBER', 'PRINT', 'OPEN_PARENT', 'CLOSE_PARENT', 'STRING', 'INT', 'DOUBLE', 'STR', 'BOOLEAN', 'CHAR', 'CHAR_VAL',
             'SEMI_COLON', 'SUM', 'SUB', 'MUL', 'DIV', 'MOD', 'EQU', 'VAR_NAME', 'TYPECAST_STR', 'TYPECAST_INT', 'BOOL_VAL', 'ARRAY', 'OPEN_ARR', 'CLOSE_ARR', 'COMMA', 'ADD', 'AND', 'NOT', 'XOR', 'OR', 'GREATER', 'LESS']
        )

    def parse(self):
        @self.pg.production('program : PRINT OPEN_PARENT expression CLOSE_PARENT SEMI_COLON')
        def my_print(p):
            return Print(p[2])

        @self.pg.production('program : PRINT OPEN_PARENT NUMBER GREATER NUMBER CLOSE_PARENT SEMI_COLON')
        def my_print(p):
            left = int(p[2].value)
            right = int(p[4].value)
            return Greater(left, right)

        @self.pg.production('program : PRINT OPEN_PARENT NUMBER LESS NUMBER CLOSE_PARENT SEMI_COLON')
        def my_print(p):
            left = int(p[2].value)
            right = int(p[4].value)
            return Less(left, right)

        @self.pg.production('program : PRINT OPEN_PARENT NUMBER EQU NUMBER CLOSE_PARENT SEMI_COLON')
        def my_print(p):
            left = int(p[2].value)
            right = int(p[4].value)
            return Equal(left, right)

        @self.pg.production('program : ARRAY OPEN_ARR CLOSE_ARR VAR_NAME')
        def arr_declaration(p):
            return Arr_Declaration(p[3].value)

        @self.pg.production('program : ARRAY OPEN_ARR NUMBER CLOSE_ARR VAR_NAME')
        def arr_declaration(p):
            return Arr_Dec_With_Size(p[4].value, p[2].value)

        @self.pg.production('program : ARRAY OPEN_ARR VAR_NAME CLOSE_ARR VAR_NAME')
        def arr_declaration(p):
            size = Get_VarValue(p[2].value).eval()
            print(size)
            return Arr_Dec_With_Size(p[4].value, size)

        @self.pg.production('program : ADD OPEN_PARENT VAR_NAME COMMA expression CLOSE_PARENT')
        def arr_add(p):
            return Arr_Add(p[2].value, p[4].value)

        @self.pg.production('program : SUB NUMBER')
        def program(p):
            return Diskrit(int(p[1].value))

        @self.pg.production('program : SUM NUMBER')
        def program(p):
            return Print(Number(int(p[1].value)))

        @self.pg.production('program : INT VAR_NAME EQU NUMBER')
        def var_assign(p):
            var_name = p[1].value
            var_value = float(p[3].value)
            res = int(var_value)
            return Var_Assign(var_name, res)

        @self.pg.production('program : INT VAR_NAME EQU VAR_NAME')
        def var_assign(p):
            var_name = p[1].value
            var_value = Get_VarValue(p[3].value).eval()
            return Var_Assign(var_name, var_value)

        @self.pg.production('program : DOUBLE VAR_NAME EQU VAR_NAME')
        def var_assign(p):
            var_name = p[1].value
            var_value = Get_VarValue(p[3].value).eval()
            return Var_Assign(var_name, var_value)

        @self.pg.production('program : BOOLEAN VAR_NAME EQU VAR_NAME')
        def var_assign(p):
            var_name = p[1].value
            var_value = Get_VarValue(p[3].value).eval()
            return Var_Assign(var_name, var_value)

        @self.pg.production('program : CHAR VAR_NAME EQU VAR_NAME')
        def var_assign(p):
            var_name = p[1].value
            var_value = Get_VarValue(p[3].value).eval()
            return Var_Assign(var_name, var_value)

        @self.pg.production('program : STRING VAR_NAME EQU VAR_NAME')
        def var_assign(p):
            var_name = p[1].value
            var_value = Get_VarValue(p[3].value).eval()
            return Var_Assign(var_name, var_value)

        @self.pg.production('program : DOUBLE VAR_NAME EQU NUMBER')
        def var_assign(p):
            var_name = p[1].value
            var_value = float(p[3].value)
            return Var_Assign(var_name, var_value)

        @self.pg.production('program : INT VAR_NAME EQU SUB NUMBER')
        def var_assign(p):
            var_name = p[1].value
            var_value = p[4].value
            val = int(var_value)
            res = val - (val * 2)
            return Var_Assign(var_name, res)

        @self.pg.production('program : INT VAR_NAME EQU SUM NUMBER')
        def var_assign(p):
            var_name = p[1].value
            var_value = p[4].value
            res = int(var_value)
            return Var_Assign(var_name, res)

        @self.pg.production('program : VAR_NAME EQU VAR_NAME')
        def var_assign(p):
            var_name = p[0].value
            var_value = Get_VarValue(p[2].value).eval()
            return Var_Assign(var_name, var_value)

        @self.pg.production('program : STR VAR_NAME EQU STRING')
        def var_assign(p):
            var_name = p[1].value
            var_value = p[3].value
            return Var_Assign(var_name, var_value)

        @self.pg.production('program : BOOLEAN VAR_NAME EQU BOOL_VAL')
        def var_assign(p):
            var_name = p[1].value
            var_value = eval(p[3].value)
            return Var_Assign(var_name, var_value)

        @self.pg.production('program : CHAR VAR_NAME EQU CHAR_VAL')
        def var_assign(p):
            var_name = p[1].value
            var_value = p[3].value
            return Var_Assign(var_name, var_value)

        @self.pg.production('program : TYPECAST_STR OPEN_PARENT VAR_NAME CLOSE_PARENT')
        def typecast_str(p):
            return Typecast_str(p[2].value)

        @self.pg.production('program : TYPECAST_INT OPEN_PARENT VAR_NAME CLOSE_PARENT')
        def typecast_int(p):
            return Typecast_int(p[2].value)

        @self.pg.production('expression : expression SUM expression')
        @self.pg.production('expression : expression SUB expression')
        @self.pg.production('expression : expression MUL expression')
        @self.pg.production('expression : expression DIV expression')
        @self.pg.production('expression : expression MOD expression')
        def expression(p):
            left = p[0]
            right = p[2]
            operator = p[1]
            if operator.gettokentype() == 'SUM':
                return Sum(left, right)
            elif operator.gettokentype() == 'SUB':
                return Sub(left, right)
            elif operator.gettokentype() == 'MUL':
                return Mul(left, right)
            elif operator.gettokentype() == 'DIV':
                return Div(left, right)
            elif operator.gettokentype() == 'MOD':
                return Mod(left, right)

        @self.pg.production('expression : NUMBER AND NUMBER')
        @self.pg.production('expression : NUMBER OR NUMBER')
        @self.pg.production('expression : NUMBER XOR NUMBER')
        def expression(p):
            left = int(p[0].value)
            right = int(p[2].value)
            operator = p[1]

            if operator.gettokentype() == 'AND':
                return And(left, right)
            elif operator.gettokentype() == 'OR':
                return Or(left, right)
            elif operator.gettokentype() == 'XOR':
                return Xor(left, right)

        @self.pg.production('expression : NOT NUMBER')
        def expression(p):
            value = int(p[1].value)
            return Not(value)

        @self.pg.production('expression : NUMBER')
        def number(p):
            return Number(p[0].value)

        @self.pg.production('expression : VAR_NAME')
        def get_var_value(p):
            return Get_VarValue(p[0].value)

        @self.pg.production('expression : STRING')
        def string(p):
            return String(p[0].value)

        @self.pg.production('expression : OPEN_ARR CLOSE_ARR VAR_NAME')
        def get_arr(p):
            return Access_Arr(p[2].value)

        @self.pg.error
        def error_handle(token):
            raise ValueError(token)

    def get_parser(self):
        return self.pg.build()
