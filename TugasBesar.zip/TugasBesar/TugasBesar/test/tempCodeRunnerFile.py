for token in tokens:
    #     print(token)