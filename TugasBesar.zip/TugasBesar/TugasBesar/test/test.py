import ply.lex as lex
import ply.yacc as yacc
import sys
tokens = [
    'INT',
    'FLOAT',
    'NAME',
    'PLUS',
    'MINUS',
    'DIVIDE',
    'MULTIPLY',
    'EQUALS',
    'LPAREN',
    'RPAREN',
    'AND',
    'OR',
    'LT'
    'LBRACKET',
    'RBRACKET'
]
t_PLUS = r'\+'
t_MINUS = r'\-'
t_MULTIPLY = r'\*'
t_DIVIDE = r'\/'
t_EQUALS = r'\='
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_AND = r'\&'
t_OR = r'\|'
t_ignore = r' '
t_lt = r'\<'
t_LBRACKET = r'\['
t_RBRACKET = r'\]'
t_XOR = r'xor'

lexer = lex.lex()
precedence = (
    ('left', 'PLUS', 'MINUS', 'RBRACKET'),
    ('left', 'MULTIPLY', 'DIVIDE', 'LBRACKET'),
    ('right', 'LPAREN', 'RPAREN'),
    ('left', 'OR', 'AND', 'LT'))


def p_expression(p):
    '''
    expression : expression PLUS expression
                | expression MINUS expression
                | expression DIVIDE expression
                | expression MULTIPLY expression
                | LPAREN expression PLUS expression RPAREN
                | LPAREN expression MINUS expression RPAREN
                | LPAREN expression DIVIDE expression RPAREN
                | LPAREN expression MULTIPLY expression RPAREN

    '''
    p[0] = (p[2], p[1], p[3])


def run(p):
    global env
    if (type(p)) == tuple:
        if p[0] == '+':
            return run(p[1]) + run(p[2])
        elif p[0] == '-':
            return run(p[1]) - run(p[2])
        elif p[0] == '/':
            return run(p[1]) / run(p[2])
        elif p[0] == '*':
            return run(p[1]) * run(p[2])
        elif p[0] == '=':
            env[p[1]] = run(p[2])
            print(env)
        elif p[0] == '<':
            env[p[1]] < run(p[2])
            print(env)
        elif p[0] == 'var':
            if p[1] not in env:
                return 'Undeclared variable found!'
            else:
                return env[p[1]]
    else:
        return p
