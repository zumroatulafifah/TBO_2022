var = {}
arr = {}
arr_val = []
arr_length = {"size": 0}


class Arr_Dec_With_Size():
    def __init__(self, arr_name, size):
        self.arr_name = arr_name
        self.size = int(size)

    def eval(self):
        arr_length["size"] = self.size
        arr[self.arr_name] = []


class Arr_Declaration():
    def __init__(self, arr_name):
        self.arr_name = arr_name

    def eval(self):
        arr_length["size"] = 1000000
        arr[self.arr_name] = []
        arr_val.clear()


class Arr_Add():
    def __init__(self, var_name, value):
        self.arr_name = var_name
        self.arr_value = value

    def eval(self):
        if len(arr_val) == arr_length["size"]:
            print("array index out of bound")
        elif len(arr_val) < arr_length["size"]:
            arr_val.append(self.arr_value)
            arr[self.arr_name] = arr_val


class Access_Arr():
    def __init__(self, var_name):
        self.arr_name = var_name

    def eval(self):
        val = arr[self.arr_name]
        self.value = val
        return self.value


class Diskrit():
    def __init__(self, value):
        self.value = value - (value * 2)

    def eval(self):
        print(self.value)


class Typecast_str():
    def __init__(self, var_name):
        self.var_name = var_name

    def eval(self):
        a = var[self.var_name]
        var[self.var_name] = str(a)


class Typecast_int():
    def __init__(self, var_name):
        self.var_name = var_name

    def eval(self):
        a = var[self.var_name]
        print(type(a))
        var[self.var_name] = int(a)
        print(type(var[self.var_name]))


class Get_VarValue():
    def __init__(self, var_name):
        variables = str(var_name)
        self.var_name = variables

    def eval(self):
        self.value = var[self.var_name]
        return self.value


class Var_Assign:
    def __init__(self, var_name, value):
        variables = str(var_name)
        self.var_name = variables
        self.value = value

    def eval(self):
        var[self.var_name] = self.value


class Number():
    def __init__(self, value):
        self.value = value

    def eval(self):
        try:
            return int(self.value)
        except:
            return float(self.value)


class Decimal():
    def __init__(self, value):
        self.value = value

    def eval(self):
        return float(self.value)


class String():
    def __init__(self, value):
        self.value = value

    def eval(self):
        return str(self.value)


class Not():
    def __init__(self, value):
        self.value = value

    def eval(self):
        return ~self.value


class And():
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self):
        return self.left & self.right


class Or():
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self):
        return self.left | self.right


class Xor():
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self):
        return self.left ^ self.right


class BinaryOp():
    def __init__(self, left, right):
        self.left = left
        self.right = right


class Sum(BinaryOp):
    def eval(self):
        return self.left.eval() + self.right.eval()


class Sub(BinaryOp):
    def eval(self):
        return self.left.eval() - self.right.eval()


class Mul(BinaryOp):
    def eval(self):
        return self.left.eval() * self.right.eval()


class Div(BinaryOp):
    def eval(self):
        return self.left.eval() / self.right.eval()


class Mod(BinaryOp):
    def eval(self):
        return self.left.eval() % self.right.eval()


class Greater():
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self):
        print(self.left > self.right)


class Less():
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self):
        print(self.left < self.right)


class Equal():
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self):
        print(self.left == self.right)


class Print():
    def __init__(self, value):
        self.value = value

    def eval(self):
        print(self.value.eval())
