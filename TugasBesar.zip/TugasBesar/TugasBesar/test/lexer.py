from rply import LexerGenerator


class Lexer():
    def __init__(self):
        self.lexer = LexerGenerator()

    def _add_tokens(self):
        # Print
        self.lexer.add('PRINT', r'print')
        # Parenthesis
        self.lexer.add('OPEN_PARENT', r'\(')
        self.lexer.add('CLOSE_PARENT', r'\)')
        # Arr
        self.lexer.add('OPEN_ARR', r'\[')
        self.lexer.add('CLOSE_ARR', r'\]')
        # Semi Colon
        self.lexer.add('SEMI_COLON', r'\;')
        # comma
        self.lexer.add('COMMA', r'\,')
        # Operators
        self.lexer.add('SUM', r'\+')
        self.lexer.add('SUB', r'\-')
        self.lexer.add('MUL', r'\*')
        self.lexer.add('DIV', r'\/')
        self.lexer.add('MOD', r'\%')
        # Number
        self.lexer.add('NUMBER', r'[0-9]+\.?[0-9]*')
        # String
        self.lexer.add('STRING', r'\".*?\"')
        # Arr
        self.lexer.add('ARRAY', r'arr')
        # add
        self.lexer.add('ADD', r'add')
        # Ignore spaces
        self.lexer.ignore(r'\s+')
        # Equals
        self.lexer.add('EQU', r'\=\s+')
        # Data type
        self.lexer.add('TYPECAST_STR', r'\$String')
        self.lexer.add('TYPECAST_INT', r'\$Integer')
        # bool
        self.lexer.add('BOOL_VAL', r'True|False')
        # char
        self.lexer.add('CHAR_VAL', r'\'.?\'')
        # identifier
        self.lexer.add('INT', r'int')
        self.lexer.add('DOUBLE', r'double')
        self.lexer.add('CHAR', r'char')
        self.lexer.add('BOOLEAN', r'bool')
        self.lexer.add('STR', r'string')
        # var
        self.lexer.add('VAR_NAME', r'\w+')
        # bitwise
        self.lexer.add('AND', r'\&')
        self.lexer.add('OR', r'\|')
        self.lexer.add('NOT', r'\~')
        self.lexer.add('XOR', r'\^')
        # relation
        self.lexer.add('GREATER', r'\>')
        self.lexer.add('LESS', r'\<')

    def get_lexer(self):
        self._add_tokens()
        return self.lexer.build()
